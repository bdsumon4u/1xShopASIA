<?php return array (
  'admin.general-setting' => 'App\\Http\\Livewire\\Admin\\GeneralSetting',
  'admin.payment-setting' => 'App\\Http\\Livewire\\Admin\\PaymentSetting',
  'admin.setting' => 'App\\Http\\Livewire\\Admin\\Setting',
  'admin.social-setting' => 'App\\Http\\Livewire\\Admin\\SocialSetting',
  'admin.top-ups-table' => 'App\\Http\\Livewire\\Admin\\TopUpsTable',
  'admin.withdraws-table' => 'App\\Http\\Livewire\\Admin\\WithdrawsTable',
  'top-ups-table' => 'App\\Http\\Livewire\\TopUpsTable',
  'withdraws-table' => 'App\\Http\\Livewire\\WithdrawsTable',
);