 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__($notice->exists ? 'Edit Notice' : 'Create Notice')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
             <?php if (isset($component)) { $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Form::class, ['method' => $notice->exists ? 'PATCH' : 'POST','class' => 'md:max-w-3xl mx-auto']); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($notice->exists ? route('admin.notices.update', $notice) : route('admin.notices.store'))]); ?>
                <div class="flex">
                    <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md w-full mt-5">
                        <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                             <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['name' => 'title','class' => 'text-redish font-bold']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </h2>
                         <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'title','class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner','value' => $notice->title]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'title']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                </div>

                <div class="flex flex-wrap md:-mx-2">
                    <div class="md:px-2 w-full md:w-1/2">
                        <div class="pt-7 pb-2 px-4 flex flex-col bg-white shadow-md relative rounded-md mt-5">
                            <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                                 <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['name' => 'type','class' => 'text-redish font-bold']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </h2>
                            <select name="type" id="type" class="tail-select mt-2 w-64">
                                <option value="top-up" <?php if($notice->type == 'top-up'): ?> selected <?php endif; ?>>Top Up</option>
                                <option value="withdraw" <?php if($notice->type == 'withdraw'): ?> selected <?php endif; ?>>Withdraw</option>
                            </select>
                             <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'type']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                </div>
                <div class="flex">
                    <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md w-full mt-5">
                        <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                             <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['name' => 'content','class' => 'text-redish font-bold']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </h2>
                         <?php if (isset($component)) { $__componentOriginaledcacb7a865cc5c7374f6f2a2787dbe759685324 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Textarea::class, ['name' => 'content','value' => $notice->content]); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['tinymce' => true]); ?>
<?php if (isset($__componentOriginaledcacb7a865cc5c7374f6f2a2787dbe759685324)): ?>
<?php $component = $__componentOriginaledcacb7a865cc5c7374f6f2a2787dbe759685324; ?>
<?php unset($__componentOriginaledcacb7a865cc5c7374f6f2a2787dbe759685324); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'content']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                </div>

                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'w-full justify-center mt-6 py-3']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full justify-center mt-6 py-3']); ?>
                    <?php echo e($notice->exists ? 'Update' : 'Publish'); ?>

                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7)): ?>
<?php $component = $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7; ?>
<?php unset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
        <script>
            var useDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;

            tinymce.init({
                selector:'[tinymce]',
                plugins: 'print preview paste importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help charmap quickbars emoticons',
                imagetools_cors_hosts: ['picsum.photos'],
                menubar: 'file edit view insert format tools table help',
                toolbar: 'undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | forecolor backcolor removeformat | charmap emoticons | fullscreen  preview save print',
                toolbar_sticky: true,
                autosave_ask_before_unload: true,
                autosave_interval: '30s',
                autosave_prefix: '{path}{query}-{id}-',
                autosave_restore_when_empty: false,
                autosave_retention: '2m',
                importcss_append: true,
                height: 600,
                image_caption: true,
                quickbars_insert_toolbar: 'link table',
                quickbars_selection_toolbar: 'bold italic underline | quicklink h2 h3 blockquote quicktable',
                noneditable_noneditable_class: 'mceNonEditable',
                toolbar_mode: 'sliding',
                contextmenu: 'link lists table',
                skin: useDarkMode ? 'oxide-dark' : 'oxide',
                content_css: useDarkMode ? 'dark' : 'default',
                content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /var/www/html/resources/views/admin/notices/editor.blade.php ENDPATH**/ ?>