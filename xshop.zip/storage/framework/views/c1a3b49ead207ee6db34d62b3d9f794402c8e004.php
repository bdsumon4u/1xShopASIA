<div class="flex flex-wrap py-3 lg:px-5 lg:py-7">
    <div class="px-3 mb-5 md:mb-0 w-full md:w-64 lg:w-80">
        <ul class="px-0 border">
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-tab="$item" class="border list-none rounded-sm <?php if($item == $tab): ?> bg-gray-800 text-gray-200 border-blue-800 <?php endif; ?>">
                <a class="block px-3 py-2" href="<?php echo e(route('admin.settings', $item)); ?>"><?php echo e(ucwords($item)); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="px-3 flex-1">
        <div class="p-4 border">
            <h3 class="text-xl mb-3">
                <span class="border-b-2 border-dashed"><?php echo e(ucwords($tab)); ?></span>
            </h3>
            <?php if(view()->exists('livewire.admin.'.$tab.'-setting')): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.'.$tab.'-setting')->html();
} elseif ($_instance->childHasBeenRendered('P3veYQv')) {
    $componentId = $_instance->getRenderedChildComponentId('P3veYQv');
    $componentTag = $_instance->getRenderedChildComponentTagName('P3veYQv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('P3veYQv');
} else {
    $response = \Livewire\Livewire::mount('admin.'.$tab.'-setting');
    $html = $response->html();
    $_instance->logRenderedChild('P3veYQv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/admin/setting.blade.php ENDPATH**/ ?>