<<?php echo e($componentName); ?> class="<?php echo e($class()); ?>" <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</<?php echo e($componentName); ?>>
<?php /**PATH /var/www/html/vendor/hotash/tall-ui-kit/resources/views/components/ordinary-tag.blade.php ENDPATH**/ ?>