 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="px-2 md:px-0 py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <h2 class="mt-2 mb-3 px-3 text-xl leading-8 font-extrabold tracking-tight text-gray-600 sm:text-2xl" style="font-family: Audiowide">
                    Pending Top Up-s
                </h2>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.top-ups-table', ['status' => 'pending'])->html();
} elseif ($_instance->childHasBeenRendered('MF0SXO3')) {
    $componentId = $_instance->getRenderedChildComponentId('MF0SXO3');
    $componentTag = $_instance->getRenderedChildComponentTagName('MF0SXO3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MF0SXO3');
} else {
    $response = \Livewire\Livewire::mount('admin.top-ups-table', ['status' => 'pending']);
    $html = $response->html();
    $_instance->logRenderedChild('MF0SXO3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="px-2 md:px-0 py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <h2 class="mt-2 mb-3 px-3 text-xl leading-8 font-extrabold tracking-tight text-gray-600 sm:text-2xl" style="font-family: Audiowide">
                    Pending Withdraw-s
                </h2>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.withdraws-table', ['status' => 'pending'])->html();
} elseif ($_instance->childHasBeenRendered('1pi0jgi')) {
    $componentId = $_instance->getRenderedChildComponentId('1pi0jgi');
    $componentTag = $_instance->getRenderedChildComponentTagName('1pi0jgi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1pi0jgi');
} else {
    $response = \Livewire\Livewire::mount('admin.withdraws-table', ['status' => 'pending']);
    $html = $response->html();
    $_instance->logRenderedChild('1pi0jgi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>