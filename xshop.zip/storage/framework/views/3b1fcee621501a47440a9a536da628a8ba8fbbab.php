<?php if($loadingIndicator): ?>
    <tbody wire:loading.class.remove="hidden" class="hidden">
        <tr>
            <td class="px-3 py-2 font-bold" colspan="<?php echo e(collect($columns)->count()); ?>">
                <?php echo app('translator')->get('laravel-livewire-tables::strings.loading'); ?>
            </td>
        </tr>
    </tbody>

    <tbody class="bg-white divide-y divide-gray-200" <?php if($collapseDataOnLoading): ?> wire:loading.remove <?php endif; ?>>
<?php else: ?>
    <tbody class="bg-white divide-y divide-gray-200">
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/vendor/laravel-livewire-tables/bootstrap-4/includes/loading.blade.php ENDPATH**/ ?>