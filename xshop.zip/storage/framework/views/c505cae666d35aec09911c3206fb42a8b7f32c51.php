 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit '.ucfirst($type))); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
             <?php if (isset($component)) { $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Form::class, ['class' => 'md:max-w-xl mx-auto','method' => 'POST']); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($route, $model->id))]); ?>
                 <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'referer','value' => request()->headers->get('referer')]); ?>
<?php $component->withName('hidden'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="flex">
                    <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md w-full mt-5">
                        <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                             <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','name' => 'player_id']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </h2>
                         <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'player_id','value' => $model->player_id,'class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'player_id']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                </div>

                <div class="flex flex-wrap md:-mx-2">
                    <div class="md:px-2 w-full md:w-1/2">
                        <div class="pt-7 pb-2 px-4 flex flex-col bg-white shadow-md relative rounded-md mt-5">
                            <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                                 <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','for' => 'currency']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Currency <?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </h2>
                            <select name="currency" id="currency" class="tail-select mt-2 w-64">
                                <?php $__currentLoopData = explode(',', setting('currencies')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($currency = trim($currency)): ?>
                                        <option value="<?php echo e($currency); ?>" <?php if(old('currency', $model->currency) == $currency): ?> selected <?php endif; ?>><?php echo e($currency); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                             <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'currency']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                    <div class="md:px-2 w-full md:w-1/2">
                        <div class="flex">
                            <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md w-full mt-5">
                                <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                                     <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','name' => 'amount']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </h2>
                                 <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'amount','value' => $model->amount,'class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'amount']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-wrap md:-mx-2">
                    <div class="md:px-2 w-full md:w-1/2">
                        <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md mt-5">
                            <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                                 <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','for' => 'payment-method']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Payment Method <?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </h2>
                            <?php $payment = app('App\Http\Livewire\Admin\PaymentSetting'); ?>
                            <select name="payment_method" id="payment-method" class="tail-select mt-2 w-64">
                                <?php $__currentLoopData = $payment->toArr(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($model->getTable() != 'withdraws'): ?> data-description="<?php echo e($number); ?>" <?php endif; ?> value="<?php echo e($name); ?>" <?php if(old('payment_method', $model->payment_method) == $name): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="md:px-2 w-full md:w-1/2">
                        <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md mt-5">
                            <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                                 <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','for' => 'status']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Change Status <?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </h2>
                            <select name="status" id="status" class="tail-select mt-2 w-64">
                                <option value="pending" <?php if($model->status == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                                <option value="completed" <?php if($model->status == 'completed'): ?> selected <?php endif; ?>>Completed</option>
                                <option value="returned" <?php if($model->status == 'returned'): ?> selected <?php endif; ?>>Returned</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="flex">
                    <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md w-full mt-5">
                        <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
                             <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','for' => 'email']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </h2>
                         <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'email','value' => $model->email,'class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'email']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                </div>

                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'w-full justify-center mt-6 py-3']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full justify-center mt-6 py-3']); ?>
                    Submit
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7)): ?>
<?php $component = $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7; ?>
<?php unset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH /var/www/html/resources/views/action.blade.php ENDPATH**/ ?>