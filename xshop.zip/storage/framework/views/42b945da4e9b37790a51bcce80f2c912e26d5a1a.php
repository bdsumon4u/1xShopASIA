<form method="<?php echo e($method == 'GET' ? 'GET' : 'POST'); ?>" class="<?php echo e($class()); ?>" <?php echo e($attributes->merge(compact('enctype'))); ?>>
    <?php if (! ($method == 'GET')): ?>
        <?php echo csrf_field(); ?>
        <?php echo method_field($method); ?>
    <?php endif; ?>
    <?php echo e($slot); ?>

</form>
<?php /**PATH /var/www/html/vendor/hotash/tall-ui-kit/resources/views/components/forms/form.blade.php ENDPATH**/ ?>