<?php $attributes = $attributes->exceptProps(['step', 'name']); ?>
<?php foreach (array_filter((['step', 'name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="flex">
    <div class="pt-7 pb-2 px-4 bg-white shadow-md relative rounded-md w-full mt-5">
        <h2 class="flex bg-white py-1 px-2 rounded-md absolute left-0 -top-3">
            <?php if($step): ?>
            <p class="mr-1 h-6 w-6 text-lg font-bold bg-redish text-white text-center rounded-md"><?php echo e($step); ?></p>
            <?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['name' => $name]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </h2>
         <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => $name,'class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => $name]); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/input-group.blade.php ENDPATH**/ ?>