<label for="<?php echo e($for); ?>" class="<?php echo e($class(['block font-medium text-sm text-gray-700'])); ?>" <?php echo e($attributes); ?> <?php if($required): ?> title="Required" <?php endif; ?>>
    <?php echo e($slot->isEmpty() ? $label() : $slot); ?>

    <?php if($required): ?> <span>*</span> <?php endif; ?>
</label>
<?php /**PATH /var/www/html/vendor/hotash/tall-ui-kit/resources/views/components/forms/label.blade.php ENDPATH**/ ?>