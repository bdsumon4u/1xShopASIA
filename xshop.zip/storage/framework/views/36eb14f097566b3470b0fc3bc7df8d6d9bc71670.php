<?php if($paginationEnabled): ?>
    <div class="bg-gray-200 py-2 px-3">
        <?php echo e($models->links()); ?>

        <?php if($models->total() <= $models->perPage()): ?>
            <?php echo app('translator')->get('laravel-livewire-tables::strings.results', [
                'first' => $models->count() ? $models->firstItem() : 0,
                'last' => $models->count() ? $models->lastItem() : 0,
                'total' => $models->total()
            ]); ?>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/vendor/laravel-livewire-tables/bootstrap-4/includes/pagination.blade.php ENDPATH**/ ?>