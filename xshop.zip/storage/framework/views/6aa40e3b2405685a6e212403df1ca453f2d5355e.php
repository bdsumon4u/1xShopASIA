 <?php if (isset($component)) { $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Form::class, ['method' => 'POST','multipart' => true]); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:submit.prevent' => 'submit']); ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.livewire-alert','data' => ['on' => 'updated']]); ?>
<?php $component->withName('livewire-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['on' => 'updated']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="flex flex-wrap md:-mx-2">
        <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="md:px-2 w-full md:w-1/2">
            <div class="flex flex-wrap items-stretch w-full mb-4 relative">
                <div class="flex -mr-px">
                    <span class="flex items-center leading-normal bg-grey-lighter rounded rounded-r-none border border-r-0 border-grey-light px-3 whitespace-no-wrap text-grey-dark text-sm">
                        <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-5 h-5" viewBox="0 0 24 24">
                            <?php echo $svg[$name]; ?>

                        </svg>
                    </span>
                </div>
                 <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => $name.'_url','type' => 'text','class' => 'flex-shrink flex-grow flex-auto leading-normal w-px flex-1 h-10 rounded rounded-l-none px-3 relative focus:border-blue focus:shadow']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($name.'_url')]); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:loading.attr' => 'disabled','class' => 'w-full justify-center mt-6 py-3']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','class' => 'w-full justify-center mt-6 py-3']); ?>
        Submit
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7)): ?>
<?php $component = $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7; ?>
<?php unset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /var/www/html/resources/views/livewire/admin/social-setting.blade.php ENDPATH**/ ?>