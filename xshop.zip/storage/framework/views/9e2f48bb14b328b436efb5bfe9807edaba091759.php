 <?php if (isset($component)) { $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Form::class, ['method' => 'POST','multipart' => true]); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:submit.prevent' => 'submit']); ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.livewire-alert','data' => ['on' => 'updated']]); ?>
<?php $component->withName('livewire-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['on' => 'updated']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="flex flex-wrap md:-mx-2">
        <div class="md:px-2 w-full md:w-1/2">
            <div class="pt-7 pb-2 px-4 bg-white border shadow-md relative rounded-md w-full mt-5">
                <h2 class="flex bg-white border py-1 px-2 rounded-md absolute left-0 -top-3">
                     <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','name' => 'company_name']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </h2>
                 <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'company_name','class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'company_name']); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'company_name']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
        <div class="md:px-2 w-full md:w-1/2">
            <div class="pt-7 pb-2 px-4 bg-white border shadow-md relative rounded-md w-full mt-5">
                <h2 class="flex bg-white border py-1 px-2 rounded-md absolute left-0 -top-3">
                     <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','name' => 'company_email']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </h2>
                 <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'company_email','class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'company_email']); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'company_email']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>

    <div class="relative flex flex-col flex-grow mt-5">
        <h2 class="z-10 flex bg-white border py-1 px-2 rounded-md absolute left-0 -top-3">
             <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','name' => 'logo']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </h2>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.file-input','data' => ['wire:model' => 'logo']]); ?>
<?php $component->withName('file-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'logo']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>

    <div class="flex">
        <div class="pt-7 pb-2 px-4 bg-white border shadow-md relative rounded-md w-full mt-5">
            <h2 class="flex bg-white border py-1 px-2 rounded-md absolute left-0 -top-3">
                 <?php if (isset($component)) { $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Label::class, ['class' => 'text-redish font-bold','for' => 'tagline']); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b)): ?>
<?php $component = $__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b; ?>
<?php unset($__componentOriginal63a17235c1f5ee88780dd047b644e286fa01a09b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </h2>
             <?php if (isset($component)) { $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Inputs\Input::class, ['name' => 'tagline','class' => 'block w-full px-2 py-1 border rounded-md text-gray-700 bg-gray-100 appearance-none focus:outline-none focus:bg-gray-200 focus:shadow-inner']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'tagline']); ?>
<?php if (isset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10)): ?>
<?php $component = $__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10; ?>
<?php unset($__componentOriginal786c525c3961a558301a48da8b4f9193d9d9ba10); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\Forms\Error::class, ['name' => 'tagline']); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117)): ?>
<?php $component = $__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117; ?>
<?php unset($__componentOriginalb0b0486f9b0f17559c6bd84e45a60fac86de7117); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>

     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:loading.attr' => 'disabled','class' => 'w-full justify-center mt-6 py-3']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','class' => 'w-full justify-center mt-6 py-3']); ?>
        Submit
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7)): ?>
<?php $component = $__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7; ?>
<?php unset($__componentOriginal51c6b17d2d3346d738c2136931e3f7dcfbba08e7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /var/www/html/resources/views/livewire/admin/general-setting.blade.php ENDPATH**/ ?>