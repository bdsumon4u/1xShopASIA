<button class="<?php echo e($class(['inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest focus:outline-none disabled:opacity-25 transition ease-in-out duration-150'])); ?>" <?php echo e($attributes->merge(compact('type'))); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /var/www/html/vendor/hotash/tall-ui-kit/resources/views/components/buttons/button.blade.php ENDPATH**/ ?>