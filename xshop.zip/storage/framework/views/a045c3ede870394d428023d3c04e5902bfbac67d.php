<footer class="bg-gray-50 text-gray-600 body-font">
    <div
        class="container px-5 md:px-15 lg:px-20 py-14 mx-auto flex md:items-center lg:items-start md:flex-row md:flex-nowrap flex-wrap flex-col">
        <div class="w-64 flex-shrink-0 md:mx-0 mx-auto text-center md:text-left">
            <a href="=<?php echo e(url('/')); ?>"
               class="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
                <img src="<?php echo e(app_logo()); ?>"
                     class="block h-7 w-auto"/>
            </a>
            <p class="mt-2 text-sm text-gray-500"><?php echo e($tagline); ?></p>
        </div>
        <div class="flex-grow flex flex-wrap md:pl-20 -mb-10 md:mt-0 mt-10 md:text-left text-center">
            <div class="md:w-3/4 w-full px-4">

            </div>
            <div class="md:w-1/4 w-full px-4">
                <h2 class="title-font font-medium text-gray-900 tracking-widest font-bold mb-3">Need Help?</h2>
                <nav class="list-none mb-10">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                         <?php if (isset($component)) { $__componentOriginal825a132068b990f9769f75e9558159367d565af5 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\OrdinaryTag::class, ['class' => 'text-gray-600 hover:text-gray-800 hover:underline']); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('page', $page))]); ?><?php echo e($page->title); ?> <?php if (isset($__componentOriginal825a132068b990f9769f75e9558159367d565af5)): ?>
<?php $component = $__componentOriginal825a132068b990f9769f75e9558159367d565af5; ?>
<?php unset($__componentOriginal825a132068b990f9769f75e9558159367d565af5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
            </div>
        </div>
    </div>
    <div class="bg-gray-100">
        <div class="container mx-auto py-4 px-5 flex flex-wrap flex-col sm:flex-row">
            <p class="text-gray-500 text-sm text-center sm:text-left">© <?php echo e(date('Y')); ?> — <?php echo e(setting('company_name', config('app.name'))); ?></p>
            <span class="inline-flex sm:ml-auto sm:mt-0 mt-2 justify-center sm:justify-start">
                <?php $social = app('App\Http\Livewire\Admin\SocialSetting'); ?>
                <?php $__currentLoopData = $social->names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($url = $social->{$name.'_url'}): ?>
                         <?php if (isset($component)) { $__componentOriginal825a132068b990f9769f75e9558159367d565af5 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\OrdinaryTag::class, ['class' => 'text-gray-500 '.e($loop->first ? '' : 'ml-3').'']); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($url)]); ?>
                          <svg fill="currentColor" stroke-linecap="round" stroke-linejoin="round"
                               stroke-width="2" class="w-5 h-5" viewBox="0 0 24 24">
                            <?php echo $social->svg[$name]; ?>

                          </svg>
                         <?php if (isset($__componentOriginal825a132068b990f9769f75e9558159367d565af5)): ?>
<?php $component = $__componentOriginal825a132068b990f9769f75e9558159367d565af5; ?>
<?php unset($__componentOriginal825a132068b990f9769f75e9558159367d565af5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php unset($social, $name, $url); ?>
            </span>
        </div>
    </div>
</footer>
<?php /**PATH /var/www/html/resources/views/welcome-footer.blade.php ENDPATH**/ ?>