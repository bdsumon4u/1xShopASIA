<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($data['subject']); ?>


<?php echo $data['message']; ?>


From,<br>
Name: <?php echo e($data['name']); ?><br>
Phone: <a href="tel:<?php echo e($data['phone']); ?>"><?php echo e($data['phone']); ?></a>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/resources/views/contact-mail.blade.php ENDPATH**/ ?>