<?php if($paginationEnabled || $searchEnabled): ?>
    <div class="bg-gray-200 py-2 px-3 flex justify-between items-center border-b">
        <div class="flex">
            <?php if($paginationEnabled && count($perPageOptions)): ?>
                <div class="flex-1">
                    <span class="hidden sm:inline"><?php echo app('translator')->get('laravel-livewire-tables::strings.per_page'); ?>: &nbsp;</span>

                    <select wire:model="perPage" class="form-input bg-gray-50 focus:bg-white w-12 rounded-md transition ease-in-out duration-150 sm:text-sm sm:leading-5">
                        <?php $__currentLoopData = $perPageOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($option); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><!--col-->
            <?php endif; ?>
        </div>
        <?php echo $__env->make('laravel-livewire-tables::'.config('laravel-livewire-tables.theme').'.includes.export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($searchEnabled): ?>
            <div class="flex rounded-lg shadow-sm">
                <div class="relative flex-grow focus-within:z-10">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="h-5 w-5 text-gray-400" viewBox="0 0 20 20" stroke="currentColor" fill="none">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </div>
                    <input
                        <?php if(is_numeric($searchDebounce) && $searchUpdateMethod === 'debounce'): ?> wire:model.debounce.<?php echo e($searchDebounce); ?>ms="search" <?php endif; ?>
                        <?php if($searchUpdateMethod === 'lazy'): ?> wire:model.lazy="search" <?php endif; ?>
                        <?php if($disableSearchOnLoading): ?> wire:loading.attr="disabled" <?php endif; ?>
                        placeholder="<?php echo e(__('laravel-livewire-tables::strings.search')); ?>"
                        class="form-input block bg-gray-50 focus:bg-white w-full rounded-md pl-10 transition ease-in-out duration-150 sm:text-sm sm:leading-5"
                    />
                    <?php if($clearSearchButton): ?>
                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                        <button wire:click="clearSearch" class="text-gray-300 hover:text-red-600 focus:outline-none">
                            <svg class="h-5 w-5 stroke-current" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/vendor/laravel-livewire-tables/bootstrap-4/includes/options.blade.php ENDPATH**/ ?>