<?php $__errorArgs = [$key, $bag];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<strong class="<?php echo e($class(['text-xs text-red-600 mt-1'])); ?>" <?php echo e($attributes); ?>>
    <?php echo e($slot->isEmpty() ? $message : $slot); ?>

</strong>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH /var/www/html/vendor/hotash/tall-ui-kit/resources/views/components/forms/error.blade.php ENDPATH**/ ?>