 <?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white overflow-hidden shadow-md">
        <div class="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
            <section class="text-gray-600 body-font">
                <div class="container mx-auto flex px-5 md:flex-row flex-col items-center">
                    <div
                        class="lg:flex-grow md:w-1/2 lg:pr-24 md:pr-16 flex flex-col md:items-start md:text-left mb-16 md:mb-0 items-center text-center">
                        <h1 class="title-font font-bold sm:text-4xl text-3xl mb-4 font-medium text-gray-800"><?php echo e($tagline); ?></h1>
                        <p class="mb-8 leading-relaxed text-gray-700" style="font-family: Roboto">You're seconds
                            away from buying Top Up Currency, Player ID. Topping Up using 1xShopASIA is more
                            easy, safe. We're trusted by millions of users in South Asia. No Credit Card
                            needed.</p>
                    </div>
                    <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6">
                        <img class="object-cover object-center rounded" alt="hero" src="<?php echo e(asset('images/cryptocurrency.jpg')); ?>">
                    </div>
                </div>
            </section>
        </div>
    </div>


    <div class="overflow-hidden shadow-md">
        <div class="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
            <div class="grid gap-6 row-gap-10 lg:grid-cols-3">
                <div class="lg:col-span-2 lg:py-6 lg:pr-16">
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '1']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Go To  <?php if (isset($component)) { $__componentOriginal825a132068b990f9769f75e9558159367d565af5 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\OrdinaryTag::class, ['class' => 'text-redish font-bold italic underline']); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['target' => '_blank','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('topup'))]); ?>Top Up <?php if (isset($__componentOriginal825a132068b990f9769f75e9558159367d565af5)): ?>
<?php $component = $__componentOriginal825a132068b990f9769f75e9558159367d565af5; ?>
<?php unset($__componentOriginal825a132068b990f9769f75e9558159367d565af5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  Page.
                     <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '2']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enter Your PlayerID. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '3']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Currency. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '4']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enter Amount. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '5']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Payment Method. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '6']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enter Your Transaction ID. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '7']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Email (Optional). <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '8']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Click On The "Buy" Button. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <div class="flex">
                        <div class="flex flex-col items-center mr-4">
                            <div>
                                <div class="flex items-center justify-center w-10 h-10 border rounded-full">
                                    <svg class="w-6 text-gray-200" stroke="currentColor" viewBox="0 0 24 24">
                                        <polyline fill="none" stroke-width="2" stroke-linecap="round"
                                                  stroke-linejoin="round" stroke-miterlimit="10"
                                                  points="6,12 10,16 18,8"></polyline>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="pt-1">
                            <p class="mb-2 text-white text-lg font-bold">Success</p>
                            <p class="text-gray-700"></p>
                        </div>
                    </div>
                </div>

                <div>
                    <h2 class="mt-2 mb-4 text-3xl leading-8 font-extrabold tracking-tight text-gray-200 sm:text-4xl"
                        style="font-family: Audiowide">
                        Top Up
                    </h2>
                    <p class="leading-relaxed text-gray-100 font-bold">
                        Top Up using 1xShopASIA is now very faster, reliable & easier. Just follow a few steps and top up your amount. Even if you don't have any kind of Card, you can pay using mobile banking also.
                    </p>
                </div>
            </div>
        </div>
    </div>


    <div class="dotted-bg overflow-hidden shadow-md">
        <div class="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
            <div class="grid gap-6 row-gap-10 lg:grid-cols-3">
                <div>
                    <h2 class="mt-2 mb-4 text-3xl leading-8 font-extrabold tracking-tight text-gray-200 sm:text-4xl"
                        style="font-family: Audiowide">
                        Withdraw
                    </h2>
                    <p class="leading-relaxed text-gray-100 font-bold">
                        Money withdraw using 1xShopASIA is now very faster, reliable & easier. Just follow a few steps and get your amount to your account. Even if you don't have any kind of Card, you can receive payment to your mobile banking also.
                    </p>
                </div>

                <div class="lg:col-span-2 lg:py-6 lg:pl-16">
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '1']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Go To  <?php if (isset($component)) { $__componentOriginal825a132068b990f9769f75e9558159367d565af5 = $component; } ?>
<?php $component = $__env->getContainer()->make(Hotash\TallUiKit\Components\OrdinaryTag::class, ['class' => 'text-redish font-bold italic underline']); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['target' => '_blank','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('withdraw'))]); ?>Withdraw <?php if (isset($__componentOriginal825a132068b990f9769f75e9558159367d565af5)): ?>
<?php $component = $__componentOriginal825a132068b990f9769f75e9558159367d565af5; ?>
<?php unset($__componentOriginal825a132068b990f9769f75e9558159367d565af5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        Page.
                     <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '2']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enter Your PlayerID. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '3']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Currency. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '4']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enter Amount. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '5']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Payment Method. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '6']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enter Your Withdrawal Code. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '7']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Email (Optional). <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '8']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Click On The "Sell" Button. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <div class="flex">
                        <div class="flex flex-col items-center mr-4">
                            <div>
                                <div class="flex items-center justify-center w-10 h-10 border rounded-full">
                                    <svg class="w-6 text-gray-200" stroke="currentColor"
                                         viewBox="0 0 24 24">
                                        <polyline fill="none" stroke-width="2" stroke-linecap="round"
                                                  stroke-linejoin="round" stroke-miterlimit="10"
                                                  points="6,12 10,16 18,8"></polyline>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="pt-1">
                            <p class="mb-2 text-white text-lg font-bold">Success</p>
                            <p class="text-gray-700"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="overflow-hidden shadow-md">
        <div class="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
            <div class="grid gap-6 row-gap-10 lg:grid-cols-3">
                <div class="lg:col-span-2 lg:py-6 lg:pr-16">
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '1']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Go To <a target="_blank" class="text-redish font-bold italic underline" href="https://1xbet.com">1xBetASIA</a> Website.
                     <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '2']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Go To Registration Page. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '3']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Country. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '4']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Select Currency. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '5']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Use Promo Code 1x24645. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '6']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Register. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Instruction::class, ['step' => '7']); ?>
<?php $component->withName('instruction'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Fill Up All Documents. <?php if (isset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42)): ?>
<?php $component = $__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42; ?>
<?php unset($__componentOriginalf791b3d5897616735f2a2416beafcb49cf12db42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <div class="flex">
                        <div class="flex flex-col items-center mr-4">
                            <div>
                                <div class="flex items-center justify-center w-10 h-10 border rounded-full">
                                    <svg class="w-6 text-gray-200" stroke="currentColor" viewBox="0 0 24 24">
                                        <polyline fill="none" stroke-width="2" stroke-linecap="round"
                                                  stroke-linejoin="round" stroke-miterlimit="10"
                                                  points="6,12 10,16 18,8"></polyline>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="pt-1">
                            <p class="mb-2 text-white text-lg font-bold">Success</p>
                            <p class="text-gray-700"></p>
                        </div>
                    </div>
                </div>

                <div>
                    <h2 class="mt-2 mb-4 text-3xl leading-8 font-extrabold tracking-tight text-gray-200 sm:text-4xl"
                        style="font-family: Audiowide">
                        1xBet Account
                    </h2>
                    <p class="leading-relaxed text-gray-100 font-bold">
                        To create 1xBetASIA account, just follow some simple steps.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white dotted-bg overflow-hidden shadow-md mb-1">
        <div class="px-2 md:px-0 pt-8 pb-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:pt-10 lg:pb-20">
            <h2 class="mt-2 mb-3 text-xl leading-8 font-extrabold tracking-tight text-gray-300 sm:text-2xl" style="font-family: Audiowide">
                Recent Top Up-s
            </h2>
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('top-ups-table', [])->html();
} elseif ($_instance->childHasBeenRendered('LYafUdu')) {
    $componentId = $_instance->getRenderedChildComponentId('LYafUdu');
    $componentTag = $_instance->getRenderedChildComponentTagName('LYafUdu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LYafUdu');
} else {
    $response = \Livewire\Livewire::mount('top-ups-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('LYafUdu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>


    <div class="bg-redish overflow-hidden shadow-md mt-1">
        <div class="px-2 md:px-0 pt-8 pb-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:pt-10 lg:pb-20">
            <h2 class="mt-2 mb-3 text-xl leading-8 font-extrabold tracking-tight text-gray-700 sm:text-2xl" style="font-family: Audiowide">
                Recent Withdraw-s
            </h2>
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('withdraws-table', [])->html();
} elseif ($_instance->childHasBeenRendered('rmbWjMl')) {
    $componentId = $_instance->getRenderedChildComponentId('rmbWjMl');
    $componentTag = $_instance->getRenderedChildComponentTagName('rmbWjMl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rmbWjMl');
} else {
    $response = \Livewire\Livewire::mount('withdraws-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('rmbWjMl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>